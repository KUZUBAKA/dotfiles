#!/usr/bin/env bash
# karukan-kz-install.sh — Karukan にパッチを当てて入れ直すスクリプト
#
# 使い方:
#   bash karukan-kz-install.sh            最新の Karukan にパッチを当てて入れる（2回目以降はアップデート）
#   bash karukan-kz-install.sh --tested   動作確認済みの版にパッチを当てて入れる
#   bash karukan-kz-install.sh --restore  パッチ無しの AUR 版 karukan-git に戻す
#
# パッチの中身:
#   1. 変換中に文字を打つと、選んでいる候補を確定して次の入力を始める
#      （~/.config/karukan-im/config.toml の [conversion] commit_on_input = false で元に戻せる）
#   2. 入力中に無変換キーを押すと、カタカナ → 半角カタカナ → ひらがな と切り替わる（Mozc・Windows と同じ）
#   3. 読みがぴったり合う辞書の候補を、続きを予測した候補より前に並べる
#      （大きな辞書を入れても、短い読みの変換が予測候補に乗っ取られない）
#   4. ウィンドウごとに辞書を読み直さず、1つの辞書を全ウィンドウで共有する
#      （メモリの節約と、新しいウィンドウで最初の1文字目が固まるのを防ぐ）
#   5. 大きなシステム辞書を読み込めるよう、読み込みの上限を引き上げる
#   6. Space の候補に、AI の文の中の1語だけを辞書の別の書き方に入れかえた候補を足す
#      （何々の旅に → 何々の度に、できていない → 出来ていない）
set -euo pipefail

readonly KZ_VERSION="1854827"
readonly PATCH_SHA256="8c504b29d20da0aad94b0ce715c6aa6ae5154fdd6af995037e40f91ceb4f9d2d"
readonly WORK_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/karukan-kz"

say()  { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m==> 注意:\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m==> エラー:\033[0m %s\n' "$*" >&2; exit 1; }

usage() {
    sed -n '2,7p' "$0" | sed 's/^# \{0,1\}//'
}

mode=latest
case "${1:-}" in
    "") ;;
    --tested) mode=tested ;;
    --restore) mode=restore ;;
    -h|--help) usage; exit 0 ;;
    *) usage; die "知らないオプションです: $1" ;;
esac

(( EUID != 0 )) || die "root（sudo）では実行しないでください。普段のユーザーのまま実行してください。"
for cmd in pacman makepkg git sha256sum b2sum; do
    command -v "$cmd" >/dev/null || die "$cmd が見つかりません。sudo pacman -S --needed base-devel git で入れてください。"
done

if [[ $mode == restore ]]; then
    command -v paru >/dev/null || die "paru が見つかりません。"
    say "パッチ無しの AUR 版 karukan-git に戻します。途中で karukan-kz-git を削除するか聞かれたら y を押してください。"
    paru -S karukan-git
    exit 0
fi

mkdir -p "$WORK_DIR"
cd "$WORK_DIR"

say "パッチを書き出しています（$WORK_DIR）"
cat > karukan-kz.patch <<'PATCH_EOF'
From 340dba0b6360217434ab557a7b5a8a74c0bc73b2 Mon Sep 17 00:00:00 2001
From: karukan-patch <noreply@example.invalid>
Date: Sat, 7 Nov 2026 23:12:11 +0900
Subject: [PATCH] =?UTF-8?q?karukan-kz:=20commit=5Fon=5Finput,=20=E7=84=A1?=
 =?UTF-8?q?=E5=A4=89=E6=8F=9B=20kana=20switching,=20exact-before-predictiv?=
 =?UTF-8?q?e=20ranking,=20shared=20dictionaries,=20larger=20dict=20limits,?=
 =?UTF-8?q?=20word=20swaps?=
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit

---
 karukan-engine/src/dict.rs                    |   6 +-
 karukan-im/core/config/default.toml           |   6 +
 karukan-im/core/src/config/settings.rs        |  24 +++
 karukan-im/core/src/core/candidate.rs         |   5 +
 karukan-im/core/src/core/engine/conversion.rs |  90 ++++++++-
 karukan-im/core/src/core/engine/init.rs       | 123 +++++++++----
 karukan-im/core/src/core/engine/mod.rs        |  10 +
 karukan-im/core/src/core/engine/mode.rs       |  87 +++++++++
 karukan-im/core/src/core/engine/swap.rs       | 141 ++++++++++++++
 .../src/core/engine/tests/commit_on_input.rs  | 173 ++++++++++++++++++
 karukan-im/core/src/core/engine/tests/mod.rs  |   9 +-
 .../core/src/core/engine/tests/muhenkan.rs    | 128 +++++++++++++
 .../core/src/core/engine/tests/rewriter.rs    |   2 +-
 .../src/core/engine/tests/shared_dicts.rs     |  75 ++++++++
 .../src/core/engine/tests/user_dict_order.rs  |  78 ++++++++
 .../core/src/core/engine/tests/word_swap.rs   |  61 ++++++
 karukan-im/core/src/core/engine/types.rs      |  17 +-
 karukan-im/core/src/core/keycode.rs           |   2 +
 18 files changed, 988 insertions(+), 49 deletions(-)
 create mode 100644 karukan-im/core/src/core/engine/swap.rs
 create mode 100644 karukan-im/core/src/core/engine/tests/commit_on_input.rs
 create mode 100644 karukan-im/core/src/core/engine/tests/muhenkan.rs
 create mode 100644 karukan-im/core/src/core/engine/tests/shared_dicts.rs
 create mode 100644 karukan-im/core/src/core/engine/tests/user_dict_order.rs
 create mode 100644 karukan-im/core/src/core/engine/tests/word_swap.rs

diff --git a/karukan-engine/src/dict.rs b/karukan-engine/src/dict.rs
index 957905d..f9a5d26 100644
--- a/karukan-engine/src/dict.rs
+++ b/karukan-engine/src/dict.rs
@@ -212,7 +212,9 @@ impl Dictionary {
         // Trie
         r.read_exact(&mut buf4)?;
         let trie_len = u32::from_le_bytes(buf4) as usize;
-        const MAX_TRIE_LEN: usize = 100 * 1024 * 1024; // 100 MB
+        // Sanity caps against a corrupt header, sized for a system dictionary
+        // extended with large vocabularies (Wikipedia, NEologd, ...).
+        const MAX_TRIE_LEN: usize = 1024 * 1024 * 1024; // 1 GiB
         if trie_len > MAX_TRIE_LEN {
             return Err(DictError::Format(format!(
                 "trie_len too large: {} (max {})",
@@ -225,7 +227,7 @@ impl Dictionary {
         // Entries
         r.read_exact(&mut buf4)?;
         let num_entries = u32::from_le_bytes(buf4) as usize;
-        const MAX_ENTRIES: usize = 10_000_000;
+        const MAX_ENTRIES: usize = 50_000_000;
         if num_entries > MAX_ENTRIES {
             return Err(DictError::Format(format!(
                 "num_entries too large: {} (max {})",
diff --git a/karukan-im/core/config/default.toml b/karukan-im/core/config/default.toml
index 8199f02..f936827 100644
--- a/karukan-im/core/config/default.toml
+++ b/karukan-im/core/config/default.toml
@@ -49,6 +49,12 @@ light_model = "jinen-v2-xsmall-q5"
 n_threads = 4
 # 起動時にライブ変換を有効にする（Ctrl+Shift+L で実行中も切替可能）
 live_conversion = true
+# 変換中（Space で候補を選んでいる間）に文字キーを押したときの動き。
+#   true : 選択中の候補を確定し、押した文字から次の入力を始める（MS-IME / Mozc と同じ）
+#   false: 確定せずに読みを伸ばして変換し直す（Karukan 本来の動き）
+# Ctrl+T / Ctrl+R / Ctrl+I で候補を絞り込んでいる間と絵文字入力中は、検索なので
+# どちらの設定でも読みを伸ばす。
+commit_on_input = true
 # ユーザー辞書: ~/.local/share/karukan-im/user_dicts/ に辞書ファイルを配置（Mozc TSV or KRKN binary）
 
 # 変換モデル。model / light_model はここのキーを参照する。値は 2 通り:
diff --git a/karukan-im/core/src/config/settings.rs b/karukan-im/core/src/config/settings.rs
index b54c333..02f5186 100644
--- a/karukan-im/core/src/config/settings.rs
+++ b/karukan-im/core/src/config/settings.rs
@@ -201,6 +201,11 @@ pub struct ConversionSettings {
     pub n_threads: u32,
     /// Enable live conversion at startup (Ctrl+Shift+L still toggles at runtime)
     pub live_conversion: bool,
+    /// A printable keystroke during an unfiltered conversion commits the
+    /// selection and starts the next composition with it (MS-IME / mozc
+    /// style). `false` keeps the refine-in-place behaviour. Narrowed source
+    /// views and the emoji picker always refine.
+    pub commit_on_input: bool,
 }
 
 /// Learning cache settings
@@ -561,6 +566,25 @@ use_context = false
         assert!(!settings.conversion.use_context);
     }
 
+    #[test]
+    fn test_commit_on_input_default_and_override() {
+        // Shipped default: typing during a conversion commits it.
+        assert!(Settings::default().conversion.commit_on_input);
+
+        let mut file = NamedTempFile::new().unwrap();
+        writeln!(
+            file,
+            r#"
+[conversion]
+commit_on_input = false
+"#
+        )
+        .unwrap();
+        let settings = Settings::load_from(file.path()).unwrap();
+        assert!(!settings.conversion.commit_on_input);
+        assert!(!crate::core::engine::EngineConfig::from_settings(&settings).commit_on_input);
+    }
+
     #[test]
     fn test_user_dict_dir() {
         let dir = Settings::user_dict_dir();
diff --git a/karukan-im/core/src/core/candidate.rs b/karukan-im/core/src/core/candidate.rs
index a4e7f0b..dc2266a 100644
--- a/karukan-im/core/src/core/candidate.rs
+++ b/karukan-im/core/src/core/candidate.rs
@@ -289,6 +289,11 @@ impl CandidateList {
         }
     }
 
+    /// Append a candidate at the end of the list.
+    pub fn push(&mut self, candidate: Candidate) {
+        self.candidates.push(candidate);
+    }
+
     /// Move the cursor to `cursor`, clamped into the list (0 when empty).
     pub fn set_cursor(&mut self, cursor: usize) {
         self.cursor = cursor.min(self.candidates.len().saturating_sub(1));
diff --git a/karukan-im/core/src/core/engine/conversion.rs b/karukan-im/core/src/core/engine/conversion.rs
index 61f8714..cf2c16a 100644
--- a/karukan-im/core/src/core/engine/conversion.rs
+++ b/karukan-im/core/src/core/engine/conversion.rs
@@ -332,7 +332,17 @@ impl InputMethodEngine {
             )
             .into_iter()
             .partition(|ac| ac.source == CandidateSource::UserDictionary);
-        for ac in user_dict {
+        // Only exact user-dictionary matches outrank the model, and every
+        // exact match comes before any predictive one (a reading extending
+        // the typed one). With a large user dictionary, predictive entries
+        // would otherwise take the top slot for any short reading (さと +
+        // Space → 悟 instead of 里) and push the system dictionary's exact
+        // matches off the first page.
+        let (user_exact, user_predictive): (Vec<_>, Vec<_>) =
+            user_dict.into_iter().partition(|ac| ac.reading.is_none());
+        let (system_exact, system_predictive): (Vec<_>, Vec<_>) =
+            system_dict.into_iter().partition(|ac| ac.reading.is_none());
+        for ac in user_exact {
             builder.push(ac);
         }
 
@@ -347,13 +357,26 @@ impl InputMethodEngine {
                 ));
             }
         } else {
+            // One word of the model's best sentence, swapped for its other
+            // dictionary spellings (何々の旅に → 何々の度に). The dictionaries
+            // below only match the whole reading, so inside a sentence these
+            // are the only dictionary alternatives there are.
+            let swaps = self.word_swap_candidates(reading, &candidates[0]);
             for text in candidates {
                 builder.push(AnnotatedCandidate::new(text, CandidateSource::Model));
             }
+            for text in swaps {
+                builder.push(AnnotatedCandidate::new(text, CandidateSource::Dictionary));
+            }
         }
 
-        // 4. System dictionary candidates
-        for ac in system_dict {
+        // 4. Exact system dictionary candidates, then the predictive ones
+        //    (user dictionary first, as among the exact matches)
+        for ac in system_exact
+            .into_iter()
+            .chain(user_predictive)
+            .chain(system_predictive)
+        {
             builder.push(ac);
         }
 
@@ -650,10 +673,14 @@ impl InputMethodEngine {
                     }
                 }
 
-                // A printable character refines instead of committing:
-                // the reading grows and the suggestion rewrites in place,
-                // keeping any active source filter.
+                // A printable character either commits the selection and
+                // starts the next composition (`commit_on_input`), or
+                // refines: the reading grows and the suggestion rewrites in
+                // place, keeping any active source filter.
                 if key.to_char().is_some() && !key.modifiers.control_key {
+                    if self.commits_on_input() {
+                        return self.commit_and_continue(key);
+                    }
                     return self.refine_through_composing(key);
                 }
 
@@ -665,6 +692,57 @@ impl InputMethodEngine {
         }
     }
 
+    /// Whether a printable keystroke commits instead of refining: only with
+    /// `commit_on_input` on, and never inside a narrowed source view or the
+    /// emoji picker — those are searches, where typing narrows the query.
+    fn commits_on_input(&self) -> bool {
+        self.config.commit_on_input
+            && self.state.filter().is_none()
+            && self.mode.current() != InputMode::Emoji
+    }
+
+    /// Commit the selected candidate exactly as Enter does (learning record
+    /// included), then feed `key` to the Empty state as the first keystroke
+    /// of the next composition — the MS-IME / mozc flow. The committed text
+    /// is appended to the left context: the frontend captures the editor's
+    /// surrounding text only when a key arrives in the Empty state, which
+    /// this keystroke never does, so without it the next composition would
+    /// be converted against the stale pre-commit context.
+    fn commit_and_continue(&mut self, key: &KeyEvent) -> EngineResult {
+        let committed = self.commit_conversion();
+        let Some(text) = committed.actions.iter().find_map(|action| match action {
+            EngineAction::Commit(text) => Some(text.clone()),
+            _ => None,
+        }) else {
+            // Nothing to commit (an empty selection): keep the old behaviour.
+            return self.refine_through_composing(key);
+        };
+        self.extend_left_context(&text);
+        // A new word starts here, like the first key in the Empty state.
+        self.metrics.adaptive_use_light_model = false;
+        let next = self.process_key_empty(key);
+        // The commit has been made either way; if the Empty state declines
+        // the key, it reaches the application after the committed text.
+        EngineResult {
+            consumed: next.consumed,
+            actions: committed.actions.into_iter().chain(next.actions).collect(),
+        }
+    }
+
+    /// Append just-committed text to the left surrounding context, keeping
+    /// the right side. Goes through `set_surrounding_context`, so the
+    /// current-line cut, the whitespace rule and the length cap all apply.
+    fn extend_left_context(&mut self, committed: &str) {
+        let (left, right) = match &self.surrounding_context {
+            Some(context) => (
+                context.left.clone().unwrap_or_default(),
+                context.right.clone().unwrap_or_default(),
+            ),
+            None => (String::new(), String::new()),
+        };
+        self.set_surrounding_context(&format!("{left}{committed}"), &right);
+    }
+
     /// Feed a refining keystroke (printable char, Backspace) through the
     /// composing path, then re-enter the conversion with the previous
     /// source filter if one was active. With a filter the composing render
diff --git a/karukan-im/core/src/core/engine/init.rs b/karukan-im/core/src/core/engine/init.rs
index addd840..9dafaab 100644
--- a/karukan-im/core/src/core/engine/init.rs
+++ b/karukan-im/core/src/core/engine/init.rs
@@ -1,6 +1,8 @@
 //! Engine initialization (model loading, dictionary setup)
 
-use std::sync::mpsc;
+use std::path::{Path, PathBuf};
+use std::sync::{Arc, Mutex, Weak, mpsc};
+use std::time::SystemTime;
 
 use anyhow::{Context, Result};
 use karukan_engine::ModelSource;
@@ -189,15 +191,18 @@ impl InputMethodEngine {
             return;
         }
 
-        match Dictionary::load(&path) {
-            Ok(dict) => {
-                debug!("System dictionary loaded from {:?}", path);
-                self.dicts.system = Some(dict);
-            }
-            Err(e) => {
-                debug!("Failed to load system dictionary from {:?}: {}", path, e);
-            }
-        }
+        let key = vec![file_stamp(&path)];
+        self.dicts.system =
+            shared_dictionary(&SYSTEM_DICT, key, || match Dictionary::load(&path) {
+                Ok(dict) => {
+                    debug!("System dictionary loaded from {:?}", path);
+                    Some(dict)
+                }
+                Err(e) => {
+                    debug!("Failed to load system dictionary from {:?}: {}", path, e);
+                    None
+                }
+            });
     }
 
     /// Initialize the learning cache from disk.
@@ -282,36 +287,84 @@ impl InputMethodEngine {
         // Sort for deterministic load order (alphabetical)
         paths.sort();
 
-        let mut dicts = Vec::new();
-        for path in &paths {
-            match Dictionary::load_auto(path) {
-                Ok(dict) => {
-                    debug!("User dictionary loaded from {:?}", path);
-                    dicts.push(dict);
+        let key = paths.iter().map(|path| file_stamp(path)).collect();
+        self.dicts.user = shared_dictionary(&USER_DICTS, key, || {
+            let mut dicts = Vec::new();
+            for path in &paths {
+                match Dictionary::load_auto(path) {
+                    Ok(dict) => {
+                        debug!("User dictionary loaded from {:?}", path);
+                        dicts.push(dict);
+                    }
+                    Err(e) => {
+                        debug!("Failed to load user dictionary from {:?}: {}", path, e);
+                    }
+                }
+            }
+
+            if dicts.is_empty() {
+                return None;
+            }
+
+            match Dictionary::merge(dicts) {
+                Ok(Some(merged)) => {
+                    debug!(
+                        "User dictionaries merged successfully ({} files from {:?})",
+                        paths.len(),
+                        dir
+                    );
+                    Some(merged)
                 }
+                Ok(None) => None,
                 Err(e) => {
-                    debug!("Failed to load user dictionary from {:?}: {}", path, e);
+                    debug!("Failed to merge user dictionaries: {}", e);
+                    None
                 }
             }
-        }
+        });
+    }
+}
 
-        if dicts.is_empty() {
-            return;
-        }
+/// Identity of a dictionary file as loaded: path, mtime and size. A rebuilt
+/// file gets a new stamp, so engines created afterwards load the new copy.
+type FileStamp = (PathBuf, Option<SystemTime>, u64);
 
-        match Dictionary::merge(dicts) {
-            Ok(Some(merged)) => {
-                debug!(
-                    "User dictionaries merged successfully ({} files from {:?})",
-                    paths.len(),
-                    dir
-                );
-                self.dicts.user = Some(merged);
-            }
-            Ok(None) => {}
-            Err(e) => {
-                debug!("Failed to merge user dictionaries: {}", e);
-            }
-        }
+fn file_stamp(path: &Path) -> FileStamp {
+    let meta = std::fs::metadata(path).ok();
+    (
+        path.to_path_buf(),
+        meta.as_ref().and_then(|m| m.modified().ok()),
+        meta.map_or(0, |m| m.len()),
+    )
+}
+
+/// The last dictionary loaded under a key, held weakly: it stays shared
+/// while any engine uses it and is freed with the last one.
+type DictSlot = Mutex<Option<(Vec<FileStamp>, Weak<Dictionary>)>>;
+
+/// fcitx5 creates one engine per input context, and every engine used to
+/// load its own copy of the dictionaries on its first key — hundreds of MB
+/// per window for a large system dictionary, and a stall on the first key
+/// of every new window. Engines in one process now share a single copy.
+static SYSTEM_DICT: DictSlot = Mutex::new(None);
+static USER_DICTS: DictSlot = Mutex::new(None);
+
+/// Return the dictionary cached under `key`, or run `load` and cache it.
+/// The slot stays locked while loading, so engines initialising at the
+/// same time wait for one load instead of each doing their own.
+fn shared_dictionary(
+    slot: &DictSlot,
+    key: Vec<FileStamp>,
+    load: impl FnOnce() -> Option<Dictionary>,
+) -> Option<Arc<Dictionary>> {
+    let mut slot = slot.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
+    if let Some((cached_key, cached)) = slot.as_ref()
+        && *cached_key == key
+        && let Some(dict) = cached.upgrade()
+    {
+        return Some(dict);
     }
+    let dict = Arc::new(load()?);
+    *slot = Some((key, Arc::downgrade(&dict)));
+    Some(dict)
 }
diff --git a/karukan-im/core/src/core/engine/mod.rs b/karukan-im/core/src/core/engine/mod.rs
index 6c6179e..61700a2 100644
--- a/karukan-im/core/src/core/engine/mod.rs
+++ b/karukan-im/core/src/core/engine/mod.rs
@@ -15,6 +15,7 @@ mod input_buffer;
 mod mode;
 mod model;
 mod strategy;
+mod swap;
 mod types;
 
 pub use types::*;
@@ -619,6 +620,15 @@ impl InputMethodEngine {
             return EngineResult::not_consumed();
         }
 
+        // 無変換: switch the kana type of the composition (bare press only,
+        // like 変換 — a modified chord may be an app or fcitx5 shortcut)
+        if key.keysym == Keysym::MUHENKAN
+            && !key.modifiers.any()
+            && let Some(result) = self.switch_kana_type()
+        {
+            return result;
+        }
+
         // Ctrl+Shift+L: toggle live conversion (works in all states)
         if key.modifiers.control_key
             && key.modifiers.shift_key
diff --git a/karukan-im/core/src/core/engine/mode.rs b/karukan-im/core/src/core/engine/mode.rs
index f9bade7..9739eb6 100644
--- a/karukan-im/core/src/core/engine/mode.rs
+++ b/karukan-im/core/src/core/engine/mode.rs
@@ -84,4 +84,91 @@ impl InputMethodEngine {
         };
         EngineResult::consumed().with_action(EngineAction::UpdateAuxText(aux))
     }
+
+    /// 無変換 — mozc's "SwitchKanaType" (MS-IME keymap). From the
+    /// composition it converts and selects the full-width katakana form;
+    /// during a conversion it cycles ひらがな → カタカナ → ﾊﾝｶｸ → ひらがな,
+    /// a non-kana selection (kanji) going to ひらがな. The candidate window
+    /// stays closed, as in MS-IME; Space reopens it, Enter or typing commits.
+    /// `None` when there is nothing to switch (Empty state, emoji queries).
+    pub(super) fn switch_kana_type(&mut self) -> Option<EngineResult> {
+        if self.mode.current() == InputMode::Emoji {
+            return None;
+        }
+        let form = match &self.state {
+            InputState::Empty => return None,
+            InputState::Composing { .. } => {
+                let result = self.start_conversion(LearningLookup::Use);
+                if !matches!(self.state, InputState::Conversion { .. }) {
+                    return Some(result);
+                }
+                KanaForm::Katakana
+            }
+            InputState::Conversion {
+                reading,
+                candidates,
+                ..
+            } => {
+                let selected = candidates.selected_text().unwrap_or_default();
+                if selected == KanaForm::Hiragana.render(reading) {
+                    KanaForm::Katakana
+                } else if selected == KanaForm::Katakana.render(reading) {
+                    KanaForm::HalfKatakana
+                } else {
+                    KanaForm::Hiragana
+                }
+            }
+        };
+        Some(self.focus_kana_form(form))
+    }
+
+    /// Select the `form` rendering of the conversion reading, adding it to
+    /// the candidate list when the list does not offer it.
+    fn focus_kana_form(&mut self, form: KanaForm) -> EngineResult {
+        let InputState::Conversion {
+            preedit,
+            candidates,
+            reading,
+            ..
+        } = &mut self.state
+        else {
+            return EngineResult::consumed();
+        };
+        let text = form.render(reading);
+        let index = match candidates.candidates().iter().position(|c| c.text == text) {
+            Some(index) => index,
+            None => {
+                let mut candidate = Candidate::with_reading(text.clone(), reading.clone());
+                candidate.source = Some(CandidateSource::Fallback);
+                candidates.push(candidate);
+                candidates.len() - 1
+            }
+        };
+        candidates.set_cursor(index);
+        *preedit = Preedit::with_text_highlighted(&text);
+        EngineResult::consumed()
+            .with_action(EngineAction::UpdatePreedit(preedit.clone()))
+            .with_action(EngineAction::HideCandidates)
+            .with_action(EngineAction::HideAuxText)
+    }
+}
+
+/// The kana renderings 無変換 cycles through.
+#[derive(Debug, Clone, Copy, PartialEq, Eq)]
+enum KanaForm {
+    Hiragana,
+    Katakana,
+    HalfKatakana,
+}
+
+impl KanaForm {
+    fn render(self, reading: &str) -> String {
+        match self {
+            KanaForm::Hiragana => reading.to_string(),
+            KanaForm::Katakana => karukan_engine::hiragana_to_katakana(reading),
+            KanaForm::HalfKatakana => karukan_engine::kana::katakana_to_half_width(
+                &karukan_engine::hiragana_to_katakana(reading),
+            ),
+        }
+    }
 }
diff --git a/karukan-im/core/src/core/engine/swap.rs b/karukan-im/core/src/core/engine/swap.rs
new file mode 100644
index 0000000..c7ee615
--- /dev/null
+++ b/karukan-im/core/src/core/engine/swap.rs
@@ -0,0 +1,141 @@
+//! Word-swap candidates: dictionary alternatives for one word inside the
+//! model's sentence.
+//!
+//! The dictionaries are only ever looked up with the whole reading, so for
+//! a sentence like 「なになにのたびに」 they contribute nothing and the
+//! model's few beams are all there is: when none of them says 度に, no
+//! number of Space presses reaches it. Here the model's best sentence is
+//! aligned with the reading from the end — the hiragana they share is
+//! kept as-is — and the word right before that shared tail is looked up
+//! on its own. When the sentence spells that word with one of the
+//! dictionary's surfaces (or leaves it in kana), every other surface of
+//! the word yields a candidate: 何々の旅に → 何々の度に, 何々の足袋に, …;
+//! できていない → 出来ていない.
+
+use super::*;
+
+/// Longest shared hiragana tail kept verbatim (okurigana and particles:
+/// に, ていない, …).
+const MAX_TAIL_CHARS: usize = 6;
+/// Word lengths tried before the tail. One-char readings are left out:
+/// they are mostly particles, and swapping those makes noise (旅に → 旅二).
+const MIN_WORD_CHARS: usize = 2;
+const MAX_WORD_CHARS: usize = 8;
+/// Surfaces taken per matched word, and candidates produced in total.
+const MAX_SURFACES_PER_WORD: usize = 6;
+const MAX_SWAPS: usize = 12;
+
+fn is_hiragana(c: char) -> bool {
+    matches!(c, '\u{3041}'..='\u{309F}' | 'ー')
+}
+
+impl InputMethodEngine {
+    /// Candidates made from `sentence` (the model's best conversion of
+    /// `reading`) by swapping one word for its other dictionary spellings.
+    /// The user dictionary is consulted before the system one.
+    pub(super) fn word_swap_candidates(&self, reading: &str, sentence: &str) -> Vec<String> {
+        let dicts: Vec<&Dictionary> = [self.dicts.user.as_deref(), self.dicts.system.as_deref()]
+            .into_iter()
+            .flatten()
+            .collect();
+        word_swaps(&dicts, reading, sentence)
+    }
+}
+
+/// The pure part of [`InputMethodEngine::word_swap_candidates`].
+pub(crate) fn word_swaps(dicts: &[&Dictionary], reading: &str, sentence: &str) -> Vec<String> {
+    let r: Vec<char> = reading.chars().collect();
+    let s: Vec<char> = sentence.chars().collect();
+    if dicts.is_empty() || r.len() < MIN_WORD_CHARS || s.is_empty() {
+        return Vec::new();
+    }
+
+    // How much hiragana the reading and the sentence end with in common.
+    let mut shared = 0;
+    while shared < r.len()
+        && shared < s.len()
+        && r[r.len() - 1 - shared] == s[s.len() - 1 - shared]
+        && is_hiragana(r[r.len() - 1 - shared])
+    {
+        shared += 1;
+    }
+
+    let mut out: Vec<String> = Vec::new();
+    // The longest kept tail first: it puts the swapped word right after
+    // the converted part (できて|いない → でき|ていない), where the model
+    // most often leaves a word in kana or picks the wrong homophone.
+    for tail_len in (0..=shared.min(MAX_TAIL_CHARS)).rev() {
+        let r_head = &r[..r.len() - tail_len];
+        let s_head = &s[..s.len() - tail_len];
+        let tail: String = r[r.len() - tail_len..].iter().collect();
+        let max_word = MAX_WORD_CHARS.min(r_head.len());
+        for word_len in (MIN_WORD_CHARS..=max_word).rev() {
+            let word: String = r_head[r_head.len() - word_len..].iter().collect();
+            for dict in dicts {
+                let Some(found) = dict.exact_match_search(&word) else {
+                    continue;
+                };
+                let surfaces: Vec<&str> = found
+                    .candidates
+                    .iter()
+                    .map(|c| c.surface.as_str())
+                    .collect();
+                // The spelling the sentence used for this word: one of the
+                // dictionary's, or the kana itself. The shortest match wins: a
+                // given-name entry may also hold the full name (シロコ, 砂狼シロコ),
+                // and only the short one lines up with the word.
+                let spelled = surfaces
+                    .iter()
+                    .copied()
+                    .chain(std::iter::once(word.as_str()))
+                    .filter(|m| !m.is_empty() && ends_with(s_head, m))
+                    .min_by_key(|m| m.chars().count());
+                let Some(spelled) = spelled else {
+                    continue;
+                };
+                let head: String = s_head[..s_head.len() - spelled.chars().count()]
+                    .iter()
+                    .collect();
+                for surface in surfaces.iter().take(MAX_SURFACES_PER_WORD) {
+                    if *surface == spelled || !is_word(surface) || overlaps(&head, surface) {
+                        continue;
+                    }
+                    let candidate = format!("{head}{surface}{tail}");
+                    if candidate != sentence && !out.contains(&candidate) {
+                        out.push(candidate);
+                        if out.len() >= MAX_SWAPS {
+                            return out;
+                        }
+                    }
+                }
+            }
+        }
+    }
+    out
+}
+
+/// Only plain words take part: entries like 「霊夢の天下とったるで!」 or
+/// 「円卓（円卓）」 are jokes and glosses, not spellings.
+fn is_word(surface: &str) -> bool {
+    surface.chars().all(|c| {
+        matches!(c,
+            '\u{3041}'..='\u{309F}' | '\u{30A1}'..='\u{30FF}' | '\u{4E00}'..='\u{9FFF}'
+            | '\u{3400}'..='\u{4DBF}' | '々' | '〆'
+            | 'a'..='z' | 'A'..='Z' | '0'..='9' | 'ａ'..='ｚ' | 'Ａ'..='Ｚ' | '０'..='９')
+    })
+}
+
+/// A surface that repeats what the sentence already says right before it:
+/// a given-name entry spelled as the full name (しろこ → 砂狼シロコ) after
+/// the family name would read 砂狼砂狼シロコ.
+fn overlaps(head: &str, surface: &str) -> bool {
+    let head: Vec<char> = head.chars().collect();
+    let surface: Vec<char> = surface.chars().collect();
+    (2..=head.len().min(surface.len().saturating_sub(1)))
+        .any(|n| head[head.len() - n..] == surface[..n])
+}
+
+fn ends_with(text: &[char], suffix: &str) -> bool {
+    let suffix: Vec<char> = suffix.chars().collect();
+    suffix.len() <= text.len() && text[text.len() - suffix.len()..] == suffix[..]
+}
diff --git a/karukan-im/core/src/core/engine/tests/commit_on_input.rs b/karukan-im/core/src/core/engine/tests/commit_on_input.rs
new file mode 100644
index 0000000..1c4ceba
--- /dev/null
+++ b/karukan-im/core/src/core/engine/tests/commit_on_input.rs
@@ -0,0 +1,173 @@
+//! `[conversion] commit_on_input`: a printable keystroke during an
+//! unfiltered conversion commits the selection and starts the next
+//! composition with it (MS-IME / mozc style).
+
+use super::*;
+
+/// Engine with `commit_on_input` on and a user dictionary entry
+/// あい → 藍, so the conversion's first candidate is deterministic.
+fn commit_on_input_engine() -> InputMethodEngine {
+    let mut engine = InputMethodEngine::with_config(EngineConfig {
+        commit_on_input: true,
+        ..EngineConfig::default()
+    });
+    engine.converters.kanji = None;
+    engine.dicts.user = Some(dict_from_json(
+        r#"[{"reading":"あい","candidates":[{"surface":"藍","score":1.0}]}]"#,
+    ));
+    engine
+}
+
+/// Type あい and press Space.
+fn convert_ai(engine: &mut InputMethodEngine) {
+    engine.process_key(&press('a'));
+    engine.process_key(&press('i'));
+    engine.process_key(&press_key(Keysym::SPACE));
+    assert!(matches!(engine.state(), InputState::Conversion { .. }));
+    assert_eq!(engine.candidates().unwrap().selected_text(), Some("藍"));
+}
+
+fn committed(result: &EngineResult) -> Option<String> {
+    result.actions.iter().find_map(|a| match a {
+        EngineAction::Commit(text) => Some(text.clone()),
+        _ => None,
+    })
+}
+
+#[test]
+fn test_typing_commits_selection_and_starts_next_composition() {
+    let mut engine = commit_on_input_engine();
+    convert_ai(&mut engine);
+
+    let result = engine.process_key(&press('k'));
+    assert!(result.consumed);
+    assert_eq!(committed(&result).as_deref(), Some("藍"));
+    assert!(matches!(engine.state(), InputState::Composing { .. }));
+
+    // The keystroke opened the next composition: k + a → か.
+    engine.process_key(&press('a'));
+    assert_eq!(engine.input_buf.reading(), "か");
+    assert_eq!(engine.preedit().unwrap().text(), "か");
+
+    // Enter commits only the new composition.
+    let result = engine.process_key(&press_key(Keysym::RETURN));
+    assert_eq!(committed(&result).as_deref(), Some("か"));
+}
+
+#[test]
+fn test_commit_precedes_the_new_preedit() {
+    // The frontend commits, resets the panel, then draws the new preedit,
+    // so Commit must come before UpdatePreedit in the same result.
+    let mut engine = commit_on_input_engine();
+    convert_ai(&mut engine);
+
+    let result = engine.process_key(&press('a'));
+    let commit_at = result
+        .actions
+        .iter()
+        .position(|a| matches!(a, EngineAction::Commit(_)))
+        .expect("commit action");
+    let preedit_at = result
+        .actions
+        .iter()
+        .rposition(|a| matches!(a, EngineAction::UpdatePreedit(_)))
+        .expect("preedit action");
+    assert!(commit_at < preedit_at);
+    assert_eq!(engine.preedit().unwrap().text(), "あ");
+}
+
+#[test]
+fn test_committed_text_is_learned() {
+    let mut engine = commit_on_input_engine();
+    engine.learning = Some(LearningCache::new(LearningConfig::default()));
+    convert_ai(&mut engine);
+    // Pick the second candidate so the record is not just the default.
+    engine.process_key(&press_key(Keysym::SPACE));
+    let picked = engine
+        .candidates()
+        .unwrap()
+        .selected_text()
+        .unwrap()
+        .to_string();
+
+    let result = engine.process_key(&press('k'));
+    assert_eq!(committed(&result).as_deref(), Some(picked.as_str()));
+    let learned = engine.learning.as_ref().unwrap().lookup("あい");
+    assert!(
+        learned.iter().any(|(surface, _)| surface == &picked),
+        "learned: {learned:?}"
+    );
+}
+
+#[test]
+fn test_digit_commits_and_starts_a_new_composition() {
+    let mut engine = commit_on_input_engine();
+    convert_ai(&mut engine);
+
+    let result = engine.process_key(&press('2'));
+    assert_eq!(committed(&result).as_deref(), Some("藍"));
+    assert_eq!(engine.input_buf.reading(), "2");
+}
+
+#[test]
+fn test_punctuation_commits_and_starts_a_new_composition() {
+    let mut engine = commit_on_input_engine();
+    convert_ai(&mut engine);
+
+    let result = engine.process_key(&press(','));
+    assert_eq!(committed(&result).as_deref(), Some("藍"));
+    assert_eq!(engine.preedit().unwrap().text(), "、");
+}
+
+#[test]
+fn test_shift_letter_commits_and_starts_direct_input() {
+    let mut engine = commit_on_input_engine();
+    convert_ai(&mut engine);
+
+    let result = engine.process_key(&press_shift('L'));
+    assert_eq!(committed(&result).as_deref(), Some("藍"));
+    assert!(engine.mode.current() == InputMode::Alphabet);
+    assert_eq!(engine.preedit().unwrap().text(), "L");
+}
+
+#[test]
+fn test_committed_text_becomes_left_context() {
+    let mut engine = commit_on_input_engine();
+    engine.set_surrounding_context("今日は", "");
+    convert_ai(&mut engine);
+
+    engine.process_key(&press('k'));
+    let left = engine
+        .surrounding_context
+        .as_ref()
+        .and_then(|c| c.left.clone());
+    assert_eq!(left.as_deref(), Some("今日は藍"));
+}
+
+#[test]
+fn test_filtered_view_still_refines() {
+    // Inside a narrowed source view typing is a search: it keeps refining.
+    let mut engine = commit_on_input_engine();
+    convert_ai(&mut engine);
+    engine.process_key(&press_ctrl(Keysym::KEY_I));
+    assert!(engine.state.filter().is_some());
+
+    let result = engine.process_key(&press('k'));
+    assert!(
+        committed(&result).is_none(),
+        "a filtered view must not commit"
+    );
+    assert!(matches!(engine.state(), InputState::Conversion { .. }));
+}
+
+#[test]
+fn test_off_keeps_refining() {
+    let mut engine = commit_on_input_engine();
+    engine.config.commit_on_input = false;
+    convert_ai(&mut engine);
+
+    let result = engine.process_key(&press('k'));
+    assert!(committed(&result).is_none());
+    engine.process_key(&press('a'));
+    assert_eq!(engine.input_buf.reading(), "あいか");
+}
diff --git a/karukan-im/core/src/core/engine/tests/mod.rs b/karukan-im/core/src/core/engine/tests/mod.rs
index 098ad3e..a5c7127 100644
--- a/karukan-im/core/src/core/engine/tests/mod.rs
+++ b/karukan-im/core/src/core/engine/tests/mod.rs
@@ -10,6 +10,7 @@ mod basic;
 mod candidate_window;
 mod candidates;
 mod chunks;
+mod commit_on_input;
 mod conversion;
 mod cursor;
 mod date;
@@ -18,16 +19,20 @@ mod katakana;
 mod learning;
 mod live_conversion;
 mod mode_toggle;
+mod muhenkan;
 mod passthrough;
 mod pending_romaji;
 mod persona;
 mod predictive;
 mod rewriter;
+mod shared_dicts;
 mod single_kanji;
 mod source_filter;
 mod strategy;
 mod surrounding;
+mod user_dict_order;
 mod width;
+mod word_swap;
 
 /// Engine seeded with a learning entry `reading → surface`, no kanji model.
 /// Bypasses `init.rs` (which gates learning on settings + file I/O) and
@@ -58,12 +63,12 @@ fn seed_model_cache(engine: &mut InputMethodEngine, katakana: &str, lctx: &str,
 }
 
 /// Build a dictionary from inline JSON, hiding the temp-file plumbing.
-fn dict_from_json(json: &str) -> Dictionary {
+fn dict_from_json(json: &str) -> std::sync::Arc<Dictionary> {
     use std::io::Write;
     let mut tmp = tempfile::NamedTempFile::new().unwrap();
     tmp.write_all(json.as_bytes()).unwrap();
     tmp.flush().unwrap();
-    Dictionary::build_from_json(tmp.path()).unwrap()
+    std::sync::Arc::new(Dictionary::build_from_json(tmp.path()).unwrap())
 }
 
 fn press(ch: char) -> KeyEvent {
diff --git a/karukan-im/core/src/core/engine/tests/muhenkan.rs b/karukan-im/core/src/core/engine/tests/muhenkan.rs
new file mode 100644
index 0000000..144408d
--- /dev/null
+++ b/karukan-im/core/src/core/engine/tests/muhenkan.rs
@@ -0,0 +1,128 @@
+//! 無変換: mozc's "SwitchKanaType" (MS-IME keymap).
+
+use super::*;
+
+fn engine_with_ai() -> InputMethodEngine {
+    let mut engine = InputMethodEngine::new();
+    engine.converters.kanji = None;
+    engine.dicts.user = Some(dict_from_json(
+        r#"[{"reading":"あい","candidates":[{"surface":"藍","score":1.0}]}]"#,
+    ));
+    engine.process_key(&press('a'));
+    engine.process_key(&press('i'));
+    engine
+}
+
+fn muhenkan(engine: &mut InputMethodEngine) -> EngineResult {
+    engine.process_key(&press_key(Keysym::MUHENKAN))
+}
+
+fn shown(engine: &InputMethodEngine) -> String {
+    engine.preedit().unwrap().text().to_string()
+}
+
+#[test]
+fn test_muhenkan_converts_the_composition_to_katakana() {
+    let mut engine = engine_with_ai();
+    let result = muhenkan(&mut engine);
+
+    assert!(result.consumed);
+    assert!(matches!(engine.state(), InputState::Conversion { .. }));
+    assert_eq!(shown(&engine), "アイ");
+    assert_eq!(engine.candidates().unwrap().selected_text(), Some("アイ"));
+    // MS-IME keeps the candidate window closed.
+    assert!(
+        result
+            .actions
+            .iter()
+            .any(|a| matches!(a, EngineAction::HideCandidates))
+    );
+    assert!(
+        !result
+            .actions
+            .iter()
+            .any(|a| matches!(a, EngineAction::Commit(_)))
+    );
+}
+
+#[test]
+fn test_muhenkan_cycles_katakana_half_hiragana() {
+    let mut engine = engine_with_ai();
+    muhenkan(&mut engine);
+    assert_eq!(shown(&engine), "アイ");
+    muhenkan(&mut engine);
+    assert_eq!(shown(&engine), "ｱｲ");
+    muhenkan(&mut engine);
+    assert_eq!(shown(&engine), "あい");
+    muhenkan(&mut engine);
+    assert_eq!(shown(&engine), "アイ");
+}
+
+#[test]
+fn test_muhenkan_from_a_kanji_selection_goes_to_hiragana() {
+    let mut engine = engine_with_ai();
+    engine.process_key(&press_key(Keysym::SPACE));
+    assert_eq!(engine.candidates().unwrap().selected_text(), Some("藍"));
+
+    muhenkan(&mut engine);
+    assert_eq!(shown(&engine), "あい");
+    muhenkan(&mut engine);
+    assert_eq!(shown(&engine), "アイ");
+}
+
+#[test]
+fn test_enter_commits_the_switched_kana() {
+    let mut engine = engine_with_ai();
+    muhenkan(&mut engine);
+    let result = engine.process_key(&press_key(Keysym::RETURN));
+    assert!(
+        result
+            .actions
+            .iter()
+            .any(|a| matches!(a, EngineAction::Commit(t) if t == "アイ"))
+    );
+    assert!(matches!(engine.state(), InputState::Empty));
+}
+
+#[test]
+fn test_typing_after_muhenkan_commits_with_commit_on_input() {
+    let mut engine = engine_with_ai();
+    engine.config.commit_on_input = true;
+    muhenkan(&mut engine);
+    let result = engine.process_key(&press('k'));
+    assert!(
+        result
+            .actions
+            .iter()
+            .any(|a| matches!(a, EngineAction::Commit(t) if t == "アイ"))
+    );
+    engine.process_key(&press('a'));
+    assert_eq!(shown(&engine), "か");
+}
+
+#[test]
+fn test_space_after_muhenkan_reopens_the_list() {
+    let mut engine = engine_with_ai();
+    muhenkan(&mut engine);
+    let result = engine.process_key(&press_key(Keysym::SPACE));
+    assert!(
+        result
+            .actions
+            .iter()
+            .any(|a| matches!(a, EngineAction::ShowCandidates(_)))
+    );
+}
+
+#[test]
+fn test_muhenkan_with_nothing_typed_passes_through() {
+    let mut engine = InputMethodEngine::new();
+    assert!(!muhenkan(&mut engine).consumed);
+}
+
+#[test]
+fn test_modified_muhenkan_is_not_hijacked() {
+    let mut engine = engine_with_ai();
+    let result = engine.process_key(&press_ctrl(Keysym::MUHENKAN));
+    assert!(!result.consumed);
+    assert!(matches!(engine.state(), InputState::Composing { .. }));
+}
diff --git a/karukan-im/core/src/core/engine/tests/rewriter.rs b/karukan-im/core/src/core/engine/tests/rewriter.rs
index f0a85c5..8ba85d0 100644
--- a/karukan-im/core/src/core/engine/tests/rewriter.rs
+++ b/karukan-im/core/src/core/engine/tests/rewriter.rs
@@ -33,7 +33,7 @@ fn conversion_texts(reading: &str) -> Vec<String> {
 }
 
 /// Build a one-entry user dictionary and load it.
-fn user_dict_with(reading: &str, surface: &str) -> Dictionary {
+fn user_dict_with(reading: &str, surface: &str) -> std::sync::Arc<Dictionary> {
     dict_from_json(&format!(
         r#"[{{"reading":"{reading}","candidates":[{{"surface":"{surface}","score":1.0}}]}}]"#
     ))
diff --git a/karukan-im/core/src/core/engine/tests/shared_dicts.rs b/karukan-im/core/src/core/engine/tests/shared_dicts.rs
new file mode 100644
index 0000000..bd64610
--- /dev/null
+++ b/karukan-im/core/src/core/engine/tests/shared_dicts.rs
@@ -0,0 +1,75 @@
+//! Engines in one process share the loaded system dictionary.
+
+use std::sync::{Arc, Mutex, MutexGuard};
+
+use super::*;
+
+/// The dictionary cache is process-wide and these tests run in parallel:
+/// without this lock one test's load evicts the other's cached copy.
+static CACHE_TESTS: Mutex<()> = Mutex::new(());
+
+fn serial() -> MutexGuard<'static, ()> {
+    CACHE_TESTS
+        .lock()
+        .unwrap_or_else(|poisoned| poisoned.into_inner())
+}
+
+fn write_dict(dir: &std::path::Path, name: &str, json: &str) -> std::path::PathBuf {
+    let dict = dict_from_json(json);
+    let path = dir.join(name);
+    dict.save(&path).unwrap();
+    path
+}
+
+#[test]
+fn test_engines_share_one_system_dictionary() {
+    let _serial = serial();
+    let dir = tempfile::tempdir().unwrap();
+    let path = write_dict(
+        dir.path(),
+        "dict.bin",
+        r#"[{"reading":"あい","candidates":[{"surface":"愛","score":1.0}]}]"#,
+    );
+    let path = path.to_str().unwrap();
+
+    let mut first = InputMethodEngine::new();
+    first.init_system_dictionary(Some(path));
+    let mut second = InputMethodEngine::new();
+    second.init_system_dictionary(Some(path));
+
+    let a = first.dicts.system.as_ref().expect("loaded");
+    let b = second.dicts.system.as_ref().expect("loaded");
+    assert!(
+        Arc::ptr_eq(a, b),
+        "the second engine must reuse the first copy"
+    );
+}
+
+#[test]
+fn test_rebuilt_dictionary_is_reloaded() {
+    let _serial = serial();
+    let dir = tempfile::tempdir().unwrap();
+    let path = write_dict(
+        dir.path(),
+        "dict.bin",
+        r#"[{"reading":"あい","candidates":[{"surface":"愛","score":1.0}]}]"#,
+    );
+    let path_str = path.to_str().unwrap().to_string();
+
+    let mut first = InputMethodEngine::new();
+    first.init_system_dictionary(Some(&path_str));
+
+    // Rebuild the file with different content (and so a different size).
+    write_dict(
+        dir.path(),
+        "dict.bin",
+        r#"[{"reading":"あい","candidates":[{"surface":"愛","score":1.0},{"surface":"藍","score":2.0}]},
+            {"reading":"うえ","candidates":[{"surface":"上","score":1.0}]}]"#,
+    );
+    let mut second = InputMethodEngine::new();
+    second.init_system_dictionary(Some(&path_str));
+
+    let fresh = second.dicts.system.as_ref().expect("loaded");
+    assert!(!Arc::ptr_eq(first.dicts.system.as_ref().unwrap(), fresh));
+    assert!(fresh.exact_match_search("うえ").is_some());
+}
diff --git a/karukan-im/core/src/core/engine/tests/user_dict_order.rs b/karukan-im/core/src/core/engine/tests/user_dict_order.rs
new file mode 100644
index 0000000..4caff15
--- /dev/null
+++ b/karukan-im/core/src/core/engine/tests/user_dict_order.rs
@@ -0,0 +1,78 @@
+//! Where user-dictionary candidates land in the Space conversion list:
+//! exact matches lead, predictive completions follow the model.
+
+use super::*;
+
+fn engine_with_user_dict(json: &str) -> InputMethodEngine {
+    let mut engine = InputMethodEngine::new();
+    engine.converters.kanji = None;
+    engine.dicts.user = Some(dict_from_json(json));
+    engine
+}
+
+fn type_and_convert(engine: &mut InputMethodEngine, romaji: &str) {
+    for ch in romaji.chars() {
+        engine.process_key(&press(ch));
+    }
+    engine.process_key(&press_key(Keysym::SPACE));
+    assert!(matches!(engine.state(), InputState::Conversion { .. }));
+}
+
+fn texts(engine: &InputMethodEngine) -> Vec<String> {
+    engine
+        .candidates()
+        .unwrap()
+        .candidates()
+        .iter()
+        .map(|c| c.text.clone())
+        .collect()
+}
+
+#[test]
+fn test_predictive_user_dict_follows_the_model() {
+    // さと + Space must not select the completion 悟 (さとる) over the
+    // model's answer for さと itself.
+    let mut engine = engine_with_user_dict(
+        r#"[{"reading":"さとる","candidates":[{"surface":"悟","score":0.0}]}]"#,
+    );
+    seed_model_cache(&mut engine, "サト", "", &["里"]);
+    type_and_convert(&mut engine, "sato");
+
+    assert_eq!(engine.candidates().unwrap().selected_text(), Some("里"));
+    let list = texts(&engine);
+    let model_at = list.iter().position(|t| t == "里").unwrap();
+    let predictive_at = list
+        .iter()
+        .position(|t| t == "悟")
+        .expect("the completion stays in the list");
+    assert!(model_at < predictive_at, "list: {list:?}");
+}
+
+#[test]
+fn test_exact_user_dict_match_still_leads() {
+    let mut engine = engine_with_user_dict(
+        r#"[{"reading":"さと","candidates":[{"surface":"郷","score":0.0}]}]"#,
+    );
+    seed_model_cache(&mut engine, "サト", "", &["里"]);
+    type_and_convert(&mut engine, "sato");
+
+    assert_eq!(engine.candidates().unwrap().selected_text(), Some("郷"));
+}
+
+#[test]
+fn test_exact_system_matches_precede_predictive_user_entries() {
+    // ほし + Space: the system dictionary's exact 星 must not be pushed down
+    // by user-dictionary completions such as ほしの → 星野.
+    let mut engine = engine_with_user_dict(
+        r#"[{"reading":"ほしの","candidates":[{"surface":"星野","score":0.0}]}]"#,
+    );
+    engine.dicts.system = Some(dict_from_json(
+        r#"[{"reading":"ほし","candidates":[{"surface":"星","score":1.0}]}]"#,
+    ));
+    type_and_convert(&mut engine, "hosi");
+
+    let list = texts(&engine);
+    let exact_at = list.iter().position(|t| t == "星").expect("exact match");
+    let predictive_at = list.iter().position(|t| t == "星野").expect("completion");
+    assert!(exact_at < predictive_at, "list: {list:?}");
+}
diff --git a/karukan-im/core/src/core/engine/tests/word_swap.rs b/karukan-im/core/src/core/engine/tests/word_swap.rs
new file mode 100644
index 0000000..b952572
--- /dev/null
+++ b/karukan-im/core/src/core/engine/tests/word_swap.rs
@@ -0,0 +1,61 @@
+//! Word-swap candidates: one word of the model's sentence replaced by its
+//! other dictionary spellings.
+
+use super::super::swap::word_swaps;
+use super::*;
+
+fn dict() -> std::sync::Arc<Dictionary> {
+    dict_from_json(
+        r#"[
+            {"reading":"たび","candidates":[{"surface":"旅","score":1.0},{"surface":"度","score":2.0},{"surface":"足袋","score":3.0}]},
+            {"reading":"でき","candidates":[{"surface":"出来","score":1.0}]},
+            {"reading":"に","candidates":[{"surface":"二","score":1.0}]}
+        ]"#,
+    )
+}
+
+#[test]
+fn swaps_the_word_before_the_shared_kana_tail() {
+    let d = dict();
+    let out = word_swaps(&[&d], "なになにのたびに", "何々の旅に");
+    assert_eq!(
+        out[..2],
+        ["何々の度に".to_string(), "何々の足袋に".to_string()]
+    );
+}
+
+#[test]
+fn spells_a_kana_word_with_the_dictionary() {
+    let d = dict();
+    let out = word_swaps(&[&d], "できていない", "できていない");
+    assert_eq!(out.first().map(String::as_str), Some("出来ていない"));
+}
+
+#[test]
+fn leaves_one_char_readings_alone() {
+    let d = dict();
+    let out = word_swaps(&[&d], "なになにのたびに", "何々の旅に");
+    assert!(!out.iter().any(|c| c.contains('二')), "{out:?}");
+}
+
+#[test]
+fn nothing_when_the_sentence_does_not_spell_the_word() {
+    let d = dict();
+    assert!(word_swaps(&[&d], "たびに", "TABIに").is_empty());
+    assert!(word_swaps(&[], "たびに", "旅に").is_empty());
+}
+
+#[test]
+fn skips_glosses_and_repeated_names() {
+    let d = dict_from_json(
+        r#"[
+            {"reading":"しろこ","candidates":[{"surface":"シロコ","score":1.0},{"surface":"砂狼シロコ","score":2.0},{"surface":"白子","score":3.0}]},
+            {"reading":"えんたく","candidates":[{"surface":"円卓","score":1.0},{"surface":"円卓（円卓）","score":2.0},{"surface":"円タク","score":3.0}]}
+        ]"#,
+    );
+    let out = word_swaps(&[&d], "すなおおかみしろこ", "砂狼シロコ");
+    assert!(out.contains(&"砂狼白子".to_string()), "{out:?}");
+    assert!(!out.iter().any(|c| c.contains("砂狼砂狼")), "{out:?}");
+    let out = word_swaps(&[&d], "えんたく", "円卓");
+    assert_eq!(out, ["円タク".to_string()]);
+}
diff --git a/karukan-im/core/src/core/engine/types.rs b/karukan-im/core/src/core/engine/types.rs
index 0f9ba86..aa386ee 100644
--- a/karukan-im/core/src/core/engine/types.rs
+++ b/karukan-im/core/src/core/engine/types.rs
@@ -107,6 +107,10 @@ pub struct EngineConfig {
     pub verbose: bool,
     /// Whether live conversion is enabled at engine startup
     pub live_conversion: bool,
+    /// Whether a printable keystroke during an unfiltered conversion commits
+    /// the selection and starts the next composition (MS-IME / mozc style)
+    /// instead of refining the reading in place
+    pub commit_on_input: bool,
     /// When the candidate window (aux line included) opens
     pub candidate_window: CandidateWindow,
     /// Which symbol the `,` `.` `/` `[` `]` keys type
@@ -142,6 +146,7 @@ impl EngineConfig {
             strategy: settings.conversion.strategy,
             verbose: settings.display.verbose,
             live_conversion: settings.conversion.live_conversion,
+            commit_on_input: settings.conversion.commit_on_input,
             candidate_window: settings.display.candidate_window,
             symbol: settings.symbol.style(),
             width: settings.width,
@@ -168,6 +173,9 @@ impl Default for EngineConfig {
             strategy: StrategyMode::default(),
             verbose: false,
             live_conversion: false,
+            // The engine default keeps the refine-in-place behaviour; the
+            // shipped config.toml default (default.toml) turns it on.
+            commit_on_input: false,
             candidate_window: CandidateWindow::default(),
             symbol: SymbolStyle::default(),
             width: WidthRules::default(),
@@ -305,13 +313,16 @@ impl LiveConversion {
     }
 }
 
-/// Dictionary store: system, user, and future cache dictionaries
+/// Dictionary store: system, user, and future cache dictionaries.
+///
+/// Both are shared (`Arc`): fcitx5 runs one engine per input context, and
+/// `init.rs` hands every engine in the process the same loaded copy.
 #[derive(Default)]
 pub(in crate::core) struct Dictionaries {
     /// System dictionary for yada double-array trie lookup
-    pub system: Option<Dictionary>,
+    pub system: Option<std::sync::Arc<Dictionary>>,
     /// User dictionary (merged from user_dict_paths)
-    pub user: Option<Dictionary>,
+    pub user: Option<std::sync::Arc<Dictionary>>,
 }
 
 /// Conversion model dispatch strategy based on input length
diff --git a/karukan-im/core/src/core/keycode.rs b/karukan-im/core/src/core/keycode.rs
index 2831fbd..2dcd908 100644
--- a/karukan-im/core/src/core/keycode.rs
+++ b/karukan-im/core/src/core/keycode.rs
@@ -45,6 +45,8 @@ impl Keysym {
     /// same value). Delivered by fcitx5 for the key right of Space on JIS
     /// keyboards.
     pub const HENKAN: Keysym = Keysym(0xff23);
+    /// 無変換 key (XK_Muhenkan), left of Space on JIS keyboards.
+    pub const MUHENKAN: Keysym = Keysym(0xff22);
 
     // Space
     pub const SPACE: Keysym = Keysym(0x0020);
-- 
2.43.0

PATCH_EOF
echo "$PATCH_SHA256  karukan-kz.patch" | sha256sum --check --quiet \
    || die "書き出したパッチが壊れています。スクリプトをもう一度ダウンロードしてください。"

cat > PKGBUILD <<'PKGBUILD_EOF'
# Local package built by karukan-kz-install.sh — not from the AUR.
# Upstream Karukan (togatoga/karukan) plus the karukan-kz patch:
#   - [conversion] commit_on_input: typing during a conversion commits it
#   - 無変換 switches the kana type (カタカナ → ﾊﾝｶｸ → ひらがな), like mozc / MS-IME
#   - exact dictionary matches rank before predictive completions, and
#     predictive user-dictionary entries no longer outrank the model
#   - every input context shares one loaded copy of the dictionaries
#   - larger dictionary load limits, for extended system dictionaries
#   - word swaps: dictionary spellings for one word inside the model's sentence
# Based on the AUR karukan-git PKGBUILD by koh11235813.
pkgname=karukan-kz-git
pkgver=0
pkgrel=1
pkgdesc="Karukan Japanese IME (fcitx5) with the karukan-kz patch: commit on typing, 無変換 kana switching, shared dictionaries"
arch=('x86_64')
url="https://github.com/togatoga/karukan"
license=('MIT OR Apache-2.0')
options=('!lto')
depends=('fcitx5' 'openssl' 'oniguruma')
makedepends=('cmake' 'extra-cmake-modules' 'rust' 'libxkbcommon' 'patchelf' 'clang' 'git')
optdepends=('fcitx5-configtool: GUI configuration tool')
provides=('karukan' 'karukan-git')
conflicts=('karukan' 'karukan-git')
source=("karukan::git+https://github.com/togatoga/karukan.git"
        "karukan-kz.patch")
b2sums=('SKIP'
        '@PATCH_B2SUM@')

# The upstream commit this patch was written and tested against. When the
# patch no longer applies to the newest upstream, this commit is built.
_tested=185482700749fd15e58555c331b4e01ce5257344

# Upstream layout, relative to the repository root
_crate="karukan-im/fcitx5"
_addondir="$_crate/fcitx5-addon"

prepare() {
    cd "$srcdir/karukan"
    if [[ ${KZ_FORCE_TESTED:-0} == 1 ]]; then
        git checkout -q "$_tested"
        git apply "$srcdir/karukan-kz.patch"
        msg2 "karukan-kz patch applied to the tested commit ${_tested:0:7} (requested)"
    elif git apply --3way "$srcdir/karukan-kz.patch"; then
        msg2 "karukan-kz patch applied to the newest upstream ($(git rev-parse --short HEAD))"
    else
        warning "the patch does not apply to the newest upstream; building the tested commit ${_tested:0:7}"
        git reset -q --hard
        git checkout -q "$_tested"
        git apply "$srcdir/karukan-kz.patch"
    fi
    rm -rf target
    cargo fetch --locked --target "$CARCH-unknown-linux-gnu"
}

pkgver() {
    cd "$srcdir/karukan"
    local desc cargo_ver=""
    if desc=$(git describe --long --abbrev=7 2>/dev/null); then
        printf '%s.kz' "$desc" | sed 's/^v//;s/\([^-]*-g\)/r\1/;s/-/./g'
    else
        [[ -f $_crate/Cargo.toml ]] &&
            cargo_ver=$(grep -m1 '^version' "$_crate/Cargo.toml" | cut -d'"' -f2)
        printf '%sr%s.g%s.kz' "${cargo_ver:+$cargo_ver.}" "$(git rev-list --count HEAD)" "$(git rev-parse --short=7 HEAD)"
    fi
}

build() {
    export LLAMA_BUILD_SHARED_LIBS=1
    export RUSTONIG_SYSTEM_LIBONIG=1
    export RUSTONIG_DYNAMIC_LIBONIG=1

    cd "$srcdir/karukan/$_addondir"
    cmake -B build -DCMAKE_INSTALL_PREFIX=/usr
    cmake --build build -j"$(nproc)"

    # The dictionary tool, built with the same flags so it reuses the
    # compiled dependencies (llama.cpp included) instead of rebuilding them.
    cd "$srcdir/karukan"
    cargo build --release --locked -p karukan-cli --bin karukan-dict
}

check() {
    cd "$srcdir/karukan"
    cargo test --release --locked -p karukan-im --lib -- core::engine::tests::commit_on_input \
        core::engine::tests::user_dict_order core::engine::tests::shared_dicts \
        core::engine::tests::word_swap \
        core::engine::tests::muhenkan \
        config::settings::tests::test_commit_on_input_default_and_override \
        --test-threads=1
}

package() {
    cd "$srcdir/karukan/$_addondir"
    DESTDIR="$pkgdir" cmake --install build
    local -A seen_libs=()
    local -a bundled_libs=()
    while IFS= read -r -d '' lib; do
        local base
        base="$(basename "$lib")"
        case "$base" in
            libllama*.so*|libggml*.so*)
                [[ -n ${seen_libs["$base"]+x} ]] && continue
                seen_libs["$base"]=1
                bundled_libs+=("$lib")
                ;;
        esac
    done < <(find "$srcdir/karukan/target/release/build" \
        -path '*/llama-cpp-sys-2-*/out/lib/lib*.so*' \
        \( -type f -o -type l \) -print0)

    if (( ${#bundled_libs[@]} == 0 )); then
        echo "error: could not find llama/ggml shared libraries to bundle" >&2
        return 1
    fi

    install -d "$pkgdir/usr/lib/fcitx5"
    for lib in "${bundled_libs[@]}"; do
        cp -a "$lib" "$pkgdir/usr/lib/fcitx5/"
    done

    while IFS= read -r -d '' elf; do
        patchelf --set-rpath '$ORIGIN' "$elf"
    done < <(find "$pkgdir/usr/lib/fcitx5" -maxdepth 1 -type f -name '*.so*' -print0)

    install -Dm755 "$srcdir/karukan/target/release/karukan-dict" "$pkgdir/usr/bin/karukan-dict"
    # Only if the tool links llama/ggml: point it at the bundled copies.
    if readelf -d "$pkgdir/usr/bin/karukan-dict" | grep -Eq 'NEEDED.*lib(llama|ggml)'; then
        patchelf --set-rpath /usr/lib/fcitx5 "$pkgdir/usr/bin/karukan-dict"
    fi

    install -Dm644 "$srcdir/karukan/LICENSE-MIT" \
        "$pkgdir/usr/share/licenses/$pkgname/LICENSE-MIT"
    install -Dm644 "$srcdir/karukan/LICENSE-APACHE" \
        "$pkgdir/usr/share/licenses/$pkgname/LICENSE-APACHE"
}
PKGBUILD_EOF
patch_b2sum=$(b2sum karukan-kz.patch | cut -d' ' -f1)
sed -i "s/@PATCH_B2SUM@/$patch_b2sum/" PKGBUILD

if [[ $mode == tested ]]; then
    export KZ_FORCE_TESTED=1
    say "動作確認済みの版（${KZ_VERSION}）にパッチを当てて作ります"
else
    say "最新の Karukan にパッチを当てて作ります（当たらなければ動作確認済みの版を使います）"
fi
say "ビルドには数分〜十数分かかります。途中で sudo のパスワードを聞かれます。"
say "「karukan-git と衝突しています。karukan-git を削除しますか？」と聞かれたら y を押してください。"

# --syncdeps: 足りないビルド用ツールを入れる / --install: できたら入れる
# --force: 同じ版でも作り直す / --clean: 作業ファイルを片付ける
makepkg --syncdeps --install --force --clean

say "インストールが終わりました: $(pacman -Q karukan-kz-git)"
# setup.sh restarts Fcitx5 itself and prints its own summary.
[[ ${KZ_FROM_SETUP:-0} == 1 ]] && exit 0
cat <<'DONE'

  次にやること: Fcitx5 を再起動して、新しい Karukan を読み込ませます。
    システム設定 → キーボード → 仮想キーボード を「なし」にして適用し、
    もう一度「Fcitx 5」に戻して適用してください。

  変換中に文字を打つと確定するようになります。元の動きに戻したいときは
  ~/.config/karukan-im/config.toml の [conversion] に
    commit_on_input = false
  と書いてください。

  Karukan を新しくしたいときは、このスクリプトをもう一度実行してください。
DONE
